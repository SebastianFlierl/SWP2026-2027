import {Auto} from "./Auto/auto.ts"
const farben = ["blue", "red", "green", "yellow"];
const automarken = ["BMW", "Mercedes", "VW", "Audi"];

//const auto = new Auto(
    //automarken[Math.floor(Math.random() * automarken.length)],
    //farben[Math.floor(Math.random() * farben.length)],
    //0
//);
//(old) auto.marke = "BMW";
//(old) auto.ps = 890;
//auto.printdata();

let anzahlAutos = 1000;
const autos:Auto[] = [];
//Erstelle anzahlAutos an Autos!!
for (let i = 1; i<=anzahlAutos;i++) {
    autos.push(
        new Auto(
        automarken[Math.floor(Math.random() * automarken.length)],
        farben[Math.floor(Math.random() * farben.length)],
        Math.floor(Math.random() * 350) + 1,
        ),
    );
}
//ausgave old
for (let i=0; i<autos.length;i++) {
    autos[i].printdata();
}
//ausgabe new=kurz
autos.forEach((auto)=>{
    auto.printdata();
});